@file:OptIn(androidx.media3.common.util.UnstableApi::class, androidx.compose.foundation.layout.ExperimentalLayoutApi::class, androidx.compose.ui.text.ExperimentalTextApi::class)

package com.ruyvor.edicao

import android.content.ContentValues
import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Text
import androidx.compose.foundation.shape.GenericShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.effect.Presentation
import androidx.media3.transformer.Composition
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.coroutines.resume
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontVariation
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

val Bg = Color(0xFF03070F)
val Cy = Color(0xFF22D3EE)
val Gr = Color(0xFF2EE6A6)
val Rd = Color(0xFFFF3B5C)
val Gy = Color(0xFFC9CED8)
val Tx = Color(0xFFAEB4C0)
val Pill = Color(0xFF1A1E27)
val PillB = Color(0xFF2B303A)
val Pl = RoundedCornerShape(50)
val Orb = FontFamily(
    Font(R.font.orbitron, FontWeight.Normal, variationSettings = FontVariation.Settings(FontVariation.weight(400))),
    Font(R.font.orbitron, FontWeight.Bold, variationSettings = FontVariation.Settings(FontVariation.weight(700))),
    Font(R.font.orbitron, FontWeight.Black, variationSettings = FontVariation.Settings(FontVariation.weight(900)))
)

enum class Fmt(val rotulo: String, val mime: String, val fator: Float, val curto: String) {
    H264("H.264 • MP4", MimeTypes.VIDEO_H264, 1f, "H.264"),
    H265("H.265 • MP4", MimeTypes.VIDEO_H265, 0.65f, "H.265")
}

enum class Res(val rotulo: String, val h: Int) {
    ORIG("ORIGINAL", 0), P1080("1080p", 1080), P720("720p", 720), P480("480p", 480), P360("360p", 360), P240("240p", 240)
}

enum class Qual(val rotulo: String, val f: Float) {
    BOA("BOA", 0.4f),
    ALTA("ALTA", 1f)
}

class Item(val uri: Uri, val nome: String, val tamanho: Long) {
    var estado by mutableStateOf("NA FILA")
    var progresso by mutableFloatStateOf(0f)
    var resultado by mutableStateOf("")
}

fun baseBps(h: Int) = when {
    h >= 2160 -> 20_000_000
    h >= 1440 -> 12_000_000
    h >= 1080 -> 8_000_000
    h >= 720 -> 4_500_000
    h >= 480 -> 2_000_000
    else -> 1_000_000
}

fun fmtTam(b: Long): String = when {
    b >= 1L shl 30 -> "%.2f GB".format(b / 1073741824.0)
    b >= 1L shl 20 -> "%.1f MB".format(b / 1048576.0)
    else -> "%d KB".format(b / 1024)
}

fun nomeDe(ctx: Context, u: Uri): String = runCatching {
    ctx.contentResolver.query(u, null, null, null, null)?.use {
        if (it.moveToFirst()) it.getString(it.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else null
    }
}.getOrNull() ?: "video"

fun tamDe(ctx: Context, u: Uri): Long = runCatching {
    ctx.contentResolver.query(u, null, null, null, null)?.use {
        if (it.moveToFirst()) it.getLong(it.getColumnIndexOrThrow(OpenableColumns.SIZE)) else 0L
    }
}.getOrNull() ?: 0L

fun alturaDe(ctx: Context, u: Uri): Int = runCatching {
    val r = MediaMetadataRetriever()
    r.setDataSource(ctx, u)
    val w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toInt() ?: 0
    val h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toInt() ?: 0
    val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toInt() ?: 0
    r.release()
    if (rot == 90 || rot == 270) w else h
}.getOrDefault(0)

/** Converte/comprime um vídeo. Retorna o tamanho final em bytes, ou -1 se falhou. */
suspend fun converter(ctx: Context, it: Item, fmt: Fmt, res: Res, q: Qual): Long = withContext(Dispatchers.Main) {
    val origH = withContext(Dispatchers.IO) { alturaDe(ctx, it.uri) }
    val alvoH = if (res == Res.ORIG || origH == 0) origH else minOf(res.h, origH)
    val escalar = res != Res.ORIG && origH > 0 && alvoH < origH
    val bps = (baseBps(if (alvoH == 0) 1080 else alvoH) * q.f * fmt.fator).toInt().coerceAtLeast(150_000)

    val tmp = File(ctx.cacheDir, "out_${System.currentTimeMillis()}.mp4")
    val efeitos = Effects(emptyList(), if (escalar) listOf(Presentation.createForHeight(alvoH)) else emptyList())
    val item = EditedMediaItem.Builder(MediaItem.fromUri(it.uri)).setEffects(efeitos).build()

    val encoder = DefaultEncoderFactory.Builder(ctx)
        .setRequestedVideoEncoderSettings(VideoEncoderSettings.Builder().setBitrate(bps).build())
        .build()

    var transformer: Transformer? = null
    val poll = launch {
        val ph = ProgressHolder()
        while (true) {
            val t = transformer
            if (t != null && t.getProgress(ph) == Transformer.PROGRESS_STATE_AVAILABLE) it.progresso = ph.progress / 100f
            delay(200)
        }
    }

    val ok = suspendCancellableCoroutine<Boolean> { cont ->
        val t = Transformer.Builder(ctx)
            .setVideoMimeType(fmt.mime)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .setEncoderFactory(encoder)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    if (cont.isActive) cont.resume(true)
                }
                override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                    if (cont.isActive) cont.resume(false)
                }
            }).build()
        transformer = t
        cont.invokeOnCancellation { t.cancel(); tmp.delete() }
        t.start(item, tmp.absolutePath)
    }
    poll.cancel()

    if (!ok) { tmp.delete(); return@withContext -1L }

    withContext(Dispatchers.IO) {
        val base = it.nome.substringBeforeLast('.')
        val nome = "RUYVOR_${base}_${System.currentTimeMillis()}.mp4"
        val v = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, nome)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/RUYVOR")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val dest = ctx.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v) ?: return@withContext -1L
        ctx.contentResolver.openOutputStream(dest)?.use { out -> tmp.inputStream().use { inp -> inp.copyTo(out, 1 shl 20) } }
        v.clear(); v.put(MediaStore.Video.Media.IS_PENDING, 0)
        ctx.contentResolver.update(dest, v, null, null)
        val tam = tmp.length()
        tmp.delete()
        tam
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContent { Tela() }
    }
}

@Composable
fun Tela() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val itens = remember { mutableStateListOf<Item>() }
    var comprimir by remember { mutableStateOf(true) }
    var fmt by remember { mutableStateOf(Fmt.H264) }
    var rodando by remember { mutableStateOf(false) }
    var tarefa by remember { mutableStateOf<kotlinx.coroutines.Job?>(null) }

    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        uris.forEach { u -> itens.add(Item(u, nomeDe(ctx, u), tamDe(ctx, u))) }
    }

    fun iniciar() {
        rodando = true
        tarefa = scope.launch {
            try {
                for (j in itens.filter { it.estado != "CONCLUÍDO" }) {
                    j.estado = "PROCESSANDO"; j.progresso = 0f
                    try {
                        val r = if (comprimir) converter(ctx, j, Fmt.H265, Res.P1080, Qual.BOA) else converter(ctx, j, fmt, Res.ORIG, Qual.ALTA)
                        if (r >= 0) {
                            j.estado = "CONCLUÍDO"; j.progresso = 1f
                            val eco = if (j.tamanho > 0) 100 - (r * 100 / j.tamanho).toInt() else 0
                            j.resultado = "${fmtTam(j.tamanho)} → ${fmtTam(r)}  (-$eco%)"
                        } else j.estado = "ERRO"
                    } catch (e: CancellationException) {
                        j.estado = "CANCELADO"; throw e
                    } catch (e: Exception) {
                        j.estado = "ERRO"
                    }
                }
                Toast.makeText(ctx, "Pronto! Salvo em Movies/RUYVOR", Toast.LENGTH_LONG).show()
            } finally { rodando = false }
        }
    }

    val total = itens.size
    val feitos = itens.count { it.estado == "CONCLUÍDO" }
    val atual = itens.firstOrNull { it.estado == "PROCESSANDO" }
    val pAtual = atual?.progresso ?: if (total > 0 && feitos == total) 1f else 0f
    val pFila = if (total == 0) 0f else (feitos + (atual?.progresso ?: 0f)) / total
    val aP by animateFloatAsState(pAtual, tween(250), label = "a")
    val aF by animateFloatAsState(pFila, tween(250), label = "f")
    val status = when {
        rodando -> "PROCESSANDO"
        total == 0 -> "AGUARDANDO"
        feitos == total -> "CONCLUÍDO"
        else -> "PRONTO"
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(Bg)
            .drawBehind {
                var y = 0f
                val passo = 4.dp.toPx()
                while (y < size.height) { drawLine(Color.White.copy(.025f), Offset(0f, y), Offset(size.width, y)); y += passo }
                drawRect(Brush.radialGradient(listOf(Cy.copy(.10f), Color.Transparent), Offset(size.width / 2, 0f), size.width))
            }
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(18.dp))
        Row {
            Text("RUYVOR", color = Gy, fontFamily = Orb, fontWeight = FontWeight.Black, fontSize = 23.sp, letterSpacing = 3.sp)
            Text("EDIÇÃO", color = Cy, fontFamily = Orb, fontWeight = FontWeight.Black, fontSize = 23.sp, letterSpacing = 3.sp,
                style = TextStyle(shadow = Shadow(Cy.copy(.7f), Offset.Zero, 22f)))
        }
        Text("DE VÍDEOS", color = Tx, fontFamily = Orb, fontSize = 11.sp, letterSpacing = 9.sp, modifier = Modifier.padding(top = 4.dp))
        Spacer(Modifier.height(14.dp))
        Pilula("＋ SELECIONAR VÍDEOS", false, Modifier.wrapContentWidth(), 44.dp, 12.sp, Modifier.padding(horizontal = 26.dp)) { pick.launch("video/*") }
        Spacer(Modifier.height(14.dp))
        Box(
            Modifier.fillMaxWidth().height(3.dp).clip(Pl)
                .background(Brush.horizontalGradient(listOf(Color.Transparent, Cy, Color.Transparent)))
        )
        Spacer(Modifier.height(18.dp))

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Pilula("COMPRIMIR", comprimir, Modifier.weight(1f), 60.dp, 14.sp) { comprimir = true }
            Pilula("CONVERTER", !comprimir, Modifier.weight(1f), 60.dp, 14.sp) { comprimir = false }
        }
        Spacer(Modifier.height(16.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Botao(if (comprimir) "H.265" else fmt.curto, Gr, Modifier.weight(.85f), 58.dp, 12.sp, false) {
                if (!comprimir && !rodando) fmt = if (fmt == Fmt.H264) Fmt.H265 else Fmt.H264
            }
            if (!rodando) Botao("INICIAR", Cy, Modifier.weight(1.4f), 72.dp, 15.sp, true) {
                if (itens.isEmpty()) Toast.makeText(ctx, "Selecione vídeos primeiro", Toast.LENGTH_SHORT).show() else iniciar()
            } else Botao("CANCELAR", Cy, Modifier.weight(1.4f), 72.dp, 14.sp, true) { tarefa?.cancel() }
            Botao("LIMPAR", Rd, Modifier.weight(.85f), 58.dp, 12.sp, true) { if (!rodando) itens.clear() }
        }
        Spacer(Modifier.height(22.dp))

        Dial(aP, aF, (aP * 100).toInt(), status, if (total > 0) "$feitos / $total" else "")

        Spacer(Modifier.height(10.dp))
        Box(Modifier.fillMaxWidth().height(1.dp).background(PillB))
        Text(
            if (comprimir) "H.265 • até 1080p • o vídeo fica bem menor."
            else "Aceita MKV, MOV, AVI, WebM, 3GP... e salva em MP4. Toque em ${fmt.curto} para trocar.",
            color = Tx, fontSize = 15.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(vertical = 18.dp)
        )
        Box(Modifier.fillMaxWidth().height(1.dp).background(PillB))

        Column(Modifier.fillMaxWidth().padding(top = 8.dp)) {
            itens.forEach { j -> Linha(j) }
        }
        Text("Salvo em Movies/RUYVOR", color = Tx.copy(.5f), fontFamily = Orb, fontSize = 10.sp, letterSpacing = 2.sp,
            modifier = Modifier.padding(vertical = 24.dp))
    }
}

fun Modifier.neon(cor: Color, on: Boolean): Modifier = if (!on) this else this.drawBehind {
    val r = CornerRadius(size.height / 2)
    for ((w, a) in listOf(26f to .05f, 16f to .08f, 8f to .14f))
        drawRoundRect(cor.copy(a), cornerRadius = r, style = Stroke(w))
}

@Composable
fun Pilula(t: String, sel: Boolean, mod: Modifier, h: Dp, fonte: TextUnit, pad: Modifier = Modifier, on: () -> Unit) {
    Box(
        mod.height(h).neon(Cy, sel).clip(Pl)
            .background(if (sel) Cy.copy(.10f) else Pill)
            .border(if (sel) 2.dp else 1.dp, if (sel) Cy else PillB, Pl)
            .clickable(onClick = on),
        contentAlignment = Alignment.Center
    ) {
        Text(t, color = if (sel) Cy else Tx, fontFamily = Orb, fontWeight = FontWeight.Bold, fontSize = fonte,
            letterSpacing = 2.sp, maxLines = 1, modifier = pad)
    }
}

@Composable
fun Botao(t: String, cor: Color, mod: Modifier, h: Dp, fonte: TextUnit, forte: Boolean, on: () -> Unit) {
    Box(
        mod.height(h).neon(cor, forte).clip(Pl)
            .background(cor.copy(if (forte) .14f else .06f))
            .border(2.dp, cor.copy(if (forte) .95f else .35f), Pl)
            .clickable(onClick = on),
        contentAlignment = Alignment.Center
    ) {
        Text(t, color = if (forte) cor else cor.copy(.7f), fontFamily = Orb, fontWeight = FontWeight.Black, fontSize = fonte,
            letterSpacing = 1.sp, maxLines = 1)
    }
}

@Composable
fun Dial(pAtual: Float, pFila: Float, pct: Int, status: String, contagem: String) {
    Box(Modifier.fillMaxWidth().aspectRatio(1f), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val c = Offset(w / 2, w / 2)
            val rOut = w * 0.485f
            for (i in 0 until 60) {
                val a = ((i * 6.0) - 90.0) * PI / 180.0
                val grande = i % 5 == 0
                val len = if (grande) w * 0.05f else w * 0.027f
                val on = pAtual > 0f && (i / 60f) <= pAtual
                val cor = when { i == 0 -> Color.White; on -> Cy; else -> Color(0xFF3A4252) }
                val p1 = Offset(c.x + cos(a).toFloat() * rOut, c.y + sin(a).toFloat() * rOut)
                val p2 = Offset(c.x + cos(a).toFloat() * (rOut - len), c.y + sin(a).toFloat() * (rOut - len))
                drawLine(cor, p1, p2, strokeWidth = (if (grande) 4f else 2.5f).dp.toPx(), cap = StrokeCap.Round)
            }
            val r1 = w * 0.375f
            val r2 = w * 0.325f
            drawCircle(Color(0xFF1B2230), r1, c, style = Stroke(2.dp.toPx()))
            drawCircle(Gr.copy(.16f), r2, c, style = Stroke(2.dp.toPx()))
            val tl1 = Offset(c.x - r1, c.y - r1); val sz1 = Size(2 * r1, 2 * r1)
            val tl2 = Offset(c.x - r2, c.y - r2); val sz2 = Size(2 * r2, 2 * r2)
            if (pAtual > 0f) {
                val sw = pAtual * 360f
                for ((g, a) in listOf(22f to .06f, 14f to .10f, 9f to .18f))
                    drawArc(Cy.copy(a), -90f, sw, false, tl1, sz1, style = Stroke(g.dp.toPx(), cap = StrokeCap.Round))
                drawArc(Cy, -90f, sw, false, tl1, sz1, style = Stroke(6.dp.toPx(), cap = StrokeCap.Round))
                val ang = (-90.0 + sw) * PI / 180.0
                val k = Offset(c.x + cos(ang).toFloat() * r1, c.y + sin(ang).toFloat() * r1)
                drawCircle(Cy.copy(.25f), 16.dp.toPx(), k)
                drawCircle(Color.White, 8.dp.toPx(), k)
            }
            if (pFila > 0f) drawArc(Gr, -90f, pFila * 360f, false, tl2, sz2, style = Stroke(3.dp.toPx(), cap = StrokeCap.Round))
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                buildAnnotatedString {
                    withStyle(SpanStyle(color = Color.White, fontSize = 58.sp)) { append("%02d".format(pct)) }
                    withStyle(SpanStyle(color = Gr, fontSize = 22.sp)) { append("%") }
                },
                fontFamily = Orb, fontWeight = FontWeight.Black
            )
            Text(status, color = Tx, fontFamily = Orb, fontSize = 13.sp, letterSpacing = 6.sp)
            if (contagem.isNotEmpty()) Text(contagem, color = Gr, fontFamily = Orb, fontSize = 12.sp, letterSpacing = 2.sp,
                modifier = Modifier.padding(top = 6.dp))
        }
    }
}

@Composable
fun Linha(j: Item) {
    Column(Modifier.fillMaxWidth().padding(vertical = 9.dp)) {
        Text(j.nome, color = Color.White, fontSize = 14.sp, maxLines = 1)
        Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(j.estado, color = if (j.estado == "ERRO") Rd else Cy, fontFamily = Orb, fontWeight = FontWeight.Bold, fontSize = 11.sp, letterSpacing = 2.sp)
            Text(if (j.estado == "PROCESSANDO") "${(j.progresso * 100).toInt()}%" else fmtTam(j.tamanho), color = Tx, fontFamily = Orb, fontSize = 11.sp)
        }
        Box(Modifier.fillMaxWidth().height(4.dp).clip(Pl).background(PillB)) {
            Box(Modifier.fillMaxWidth(j.progresso.coerceIn(0f, 1f)).fillMaxHeight().background(Cy))
        }
        if (j.resultado.isNotEmpty()) Text(j.resultado, color = Gr, fontFamily = Orb, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
    }
}
