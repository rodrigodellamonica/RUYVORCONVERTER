# RUYVOR EDIÇÃO DE VÍDEOS
App Android 100% Kotlin (Jetpack Compose + Media3 Transformer) para converter e comprimir vídeos.

1. Suba esta pasta inteira num repositório do GitHub (branch main).
2. Aba **Actions** → workflow **Build APK** roda sozinho (ou "Run workflow").
3. Baixe o APK em **Artifacts** → `RUYVOR-EDICAO-DE-VIDEOS-apk`.

Os vídeos prontos ficam em **Movies/RUYVOR**.
